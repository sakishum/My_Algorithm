/*******************************************************************************
*
* FileName : test_for_binary_tree.cpp
* Comment  : binary tree
* Version  : 1.0
* Author   : haibindev.cnblogs.com
* Date     : 2007-9-23 0:04
*
*******************************************************************************/

#include <iostream>
#include "binary_tree.h"

int main()
{
	Binary_tree<int>* p=0;
	return 0;
}