/*******************************************************************************
*
* FileName : test_for_graph_list.cpp
* Comment  : #####
* Version  : 1.0
* Author   : haibindev.cnblogs.com
* Date     : 2007-- :
*
*******************************************************************************/

#include <iostream>
#include "graph_list.h"

int main()
{
	return 0;
}