/*******************************************************************************
*
* FileName : test_for_heap.cpp
* Comment  : test
* Version  : 1.0
* Author   : haibindev.cnblogs.com
* Date     : 2007-9-25 1:07
*
*******************************************************************************/

#include <iostream>
#include "heap.h"

int main()
{
	return 0;
}