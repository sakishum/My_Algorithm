/*******************************************************************************
*
* FileName : test_for_object_count.cpp
* Comment  : do nothing
* Version  : 1.0
* Author   : haibindev.cnblogs.com
* Date     : 2007-10-10 10:51
*
*******************************************************************************/

#include <iostream>
#include "object_count.h"

int main()
{
	return 0;
}