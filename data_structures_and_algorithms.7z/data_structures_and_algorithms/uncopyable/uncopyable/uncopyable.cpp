/*******************************************************************************
*
* FileName : uncopyable.cpp
* Comment  : do nothing
* Version  : 1.0
* Author   : haibindev.cnblogs.com
* Date     : 2007-10-10 19:06
*
*******************************************************************************/

#include <iostream>
#include "uncopyable.h"

int main()
{
	return 0;
}